<?php 
    $l_inicio = '"http://localhost/ultratech/inicio.php"';
    $l_precios = '"http://localhost/ultratech/precios.php"';
    $l_prfs = '"http://localhost/ultratech/prfs.php"';
    $l_email = '"mailto:ultratech.chile@gmail.com?subject=Contacto%20desde%20sitio%20web&body=Escriba%20sus%20dudas,%20consultas%20o%20comentarios%20aqui..."';
    $l_wsp = '"https://wa.me/56953077891"';
    $l_ig = '"https://www.instagram.com/ultratech.chile"';
    /*  local test http://localhost/ultratech 
        produccion https://ultratech.infinityfreeapp.com */
?>