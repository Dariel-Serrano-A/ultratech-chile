
<!DOCTYPE html>
<html lang="es">
<head>
    <?php include 'head.php' ;?>          
</head>
<body>
    <header>  
    </header>
    
    <nav>
        <?php include 'nav.php' ;?>
    </nav>

    <main>
    <div class="container-fluid px-5 cntr-green">
            <div class="row">             
                <div class="col-xl-12 mb-3 px-2">
                    <?php include 'preciostabla.php' ;?>                                                   
                </div>
            </div>
        </div>
    </main>

    <footer>
        <?php include 'footer.php' ;?>
    </footer>
</body>
</html>
